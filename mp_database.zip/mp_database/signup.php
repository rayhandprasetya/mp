<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['pnumber']) && isset($_POST['email']) && isset($_POST['password'])) {
    if ($db->dbConnect()) {
        if ($db->signUp("clients", $_POST['fname'], $_POST['lname'], $_POST['pnumber'], $_POST['email'], $_POST['password'])) {
            echo "Sign Up Success";
        } 
        else {
            echo "Sign up Failed";
        }
    } 
    else {
        echo "Error: Database connection";
    }
} 
else {
    echo "You're in!";
}
?>



